'''
* Fill each each function stub according to the docstring.
* To run the unit tests: Make sure you are in the root dir(assessment-3)
  Then run the tests with this command: "make test"
'''

import numpy as np
from scipy import stats
import pandas as pd
import random


# Probability
def roll_the_dice(n_simulations = 1000):
    '''
    INPUT: INT
    OUTPUT: FLOAT

    Two unbiased, six sided, dice are thrown once and the sum of the showing
    faces is observed (so if you rolled a 3 and a 1, you would observe the sum,
    4). Use a simulation to find the estimated probability that the total score
    is an even number or a number greater than 7.  Your function should return
    an estimated probability, based on rolling the two dice n_simulations times.
    '''
    uniform_prior = {1: 0.167, 2: 0.167, 3: 0.167, 4: 0.167, 5: 0.167, 6: 0.167}

#Probability of total score is an even number greater than 7 / Prior = 0.00038580246913580245

# Statistics
def calculate_t_test(sample1, sample2, type_I_error_rate):
    '''
    INPUT: NUMPY ARRAY, NUMPY ARRAY
    OUTPUT: FLOAT, BOOLEAN

    You are asked to evaluate whether the two samples come from a population
    with the same population mean.  Return a tuple containing the p-value for
    the pair of samples and True or False depending if the p-value is
    considered significant at the provided Type I Error Rate (i.e. false
    positive rate, i.e. alpha).
    '''
    p_value = stats.ttest_ind(sample1, sample2, equal_var = FALSE)[1]
    def sig(p_value):
        if p_value > type_I_error_rate:
            return False
        else:
            return True
    return p_value
    #I don't know how to return the boolean value in a tuple!
    #Am I on the right track defining a function for significance?


# Pandas
def pandas_query(df):
    '''
    INPUT: DATAFRAME
    OUTPUT: DATAFRAME

    Given a DataFrame containing university data with these columns:
        name, address, Website, Type, Size

    Return the DataFrame containing the average size for each university
    type ordered by average size in ascending order.
    '''

    df = pd.DataFrame(np.sort(df["Size"].mean()))


def df_to_numpy(df, y_column):
    '''
    INPUT: DATAFRAME, STRING
    OUTPUT: 2 DIMENSIONAL NUMPY ARRAY, NUMPY ARRAY

    Make the column named y_column into a numpy array (y) and make the rest of
    the DataFrame into a 2 dimensional numpy array (X). Return (X, y).

    E.g.
                a  b  c
        df = 0  1  3  5
             1  2  4  6
        y_column = 'c'

        output: np.array([[1, 3], [2, 4]]), np.array([5, 6])
    '''
    pass


# Numpy
def size_of_multiply(A, B):
    '''
    INPUT: 2 DIMENSIONAL NUMPY ARRAY, 2 DIMENSIONAL NUMPY ARRAY
    OUTPUT: TUPLE

    If matrices A (dimensions m x n) and B (dimensions p x q) can be
    multiplied (AB), return the shape of the result of multiplying them. Use the
    shape function. DO NOT ACTUALLY MULTIPLY THE MATRICES, just return the
    shape.

    If A and B cannot be multiplied, return None.
    '''
    #This is where I'd start:
    if len(m) == len(q):
        return np.dot(A, B)
    else:
        return None


# SQL
def sql_query():
    '''
    INPUT: None
    OUTPUT: STRING

    Given a table named universities which contains university data with these
    columns:

        name, address, Website, Type, Size

    Return a SQL query that gives the average size of each university type
    in ascending order.
    '''
    # Your code should look like this:
    # return '''SELECT * FROM universities;'''
    return '''SELECT AVG(Size) as avg
    FROM universities
    ORDER BY avg ASC;'''
